﻿export class User {
    id: number;
    usuario: string;
    senha: string;
    nome?: string;
    cargo?: string;
    token?: string;
}